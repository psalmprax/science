# Validation

Offline test suite: `pytest -q tests/test_receipt_runner.py`.

The tests cover pinned baseline identifiers, nested receipt lookup, fail-closed comparison checks, safe argv token substitution, and geometric-mean calculation. They use no official verifier and generate no official receipts.
