import importlib.util
import math
from pathlib import Path

SCRIPT = Path(__file__).parents[1] / "scripts" / "run_official_receipts.py"
spec = importlib.util.spec_from_file_location("receipt_runner", SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def test_baselines_are_pinned_and_positive():
    assert set(mod.BASELINES) == {"invsqrt", "dqi", "dfthcsos"}
    assert all(math.isfinite(v) and v > 0 for v in mod.BASELINES.values())


def test_value_at_nested_fields_and_lists():
    obj = {"resources": {"angles": [{"qubits": 128}]}}
    assert mod.value_at(obj, "resources.angles.0.qubits") == 128
    assert mod.value_at(obj, "resources.angles.1.qubits") is None


def test_comparison_operators_fail_closed():
    assert mod.check_comparison(128, {"op": "le", "value": 128})[0]
    assert not mod.check_comparison(None, {"op": "le", "value": 128})[0]
    assert mod.check_comparison("PASS", {"op": "eq", "value": "PASS"})[0]
    assert not mod.check_comparison(1, {"op": "magic", "value": 1})[0]


def test_command_rendering_uses_literal_argv_tokens():
    cmd = mod.render_command(["python", "{repo_root}/build.py", "--out", "{run_dir}"],
                             {"repo_root": "/repo path", "run_dir": "/out path"})
    assert cmd == ["python", "/repo path/build.py", "--out", "/out path"]


def test_geometric_mean_is_cubic_not_product():
    ratios = [13.081, 14.396, 1.580]
    product = math.prod(ratios)
    gm = product ** (1 / 3)
    assert product > 290
    assert 6.6 < gm < 6.8
