# DFTHCSOS Arm 2 — Reed–Muller angle-buffering experiment gate

This package separates **Arm 2: Reed–Muller angle buffering** from the rejected SelectSwap-only arm. It contains a plan-only layout screen, a receipt/manifest auditor, and tests. It is not the exact ANGLE generator, a Reed–Muller compiler, or an official verification run.

## Frozen baseline supplied for this experiment

- Official incumbent receipt score: `3355599588.3155365`
- `lambda_eff`: `49.30136925057438`
- `Q_total`: `730`
- `T_total`: `93237.0`
- Official input (`submission.npz`) SHA-256 reported by the workspace: `276d464ff14da828b6b33e8487d99975494cbdf0c3cb2bd37dd3c3ddc4002695`
- Measured incumbent ANGLE circuits: 10 circuits, 119 qubits each; 12 selector + 8×12-bit words + 11 ancillas; 9-qubit headroom under the 128-qubit cap.

The package does not bake the receipt hash in as an authenticated verifier output. Use the exact on-disk `baseline_receipt.json` and source-member manifest as inputs to the full experiment ledger.

## Candidate layouts to examine first

The prior project notes propose two candidate layouts, which are **analytical starting points, not verified designs**:

| Candidate | Block size | Angle batch `J` | Estimated total qubits under the project formula `634 + 12J` |
|---|---:|---:|---:|
| `rm_block2_j4` | 2 | 4 | 682 |
| `rm_block4_j6` | 4 | 6 | 706 |

The angle-qubit width is calculated as `selection_qubits + J*word_bits + ancilla_qubits + buffered_delta_bits + phase_fixup_qubits`. Do not supply the delta and phase-fixup widths until measured from the exact implementation. If those values are unknown, the tool reports feasibility as unknown rather than guessing. In particular, the `J=6`, block-size-4 case only fits at the nominal cap if the measured extra delta and fix-up width totals no more than 33 qubits.

## Run the planning screen

```bash
python scripts/plan_dfthcsos_arm2.py \
  --address-count 3976 --word-bits 12 --selection-qubits 12 \
  --ancilla-qubits 11 --qubit-cap 128 \
  --output artifacts/quantum_compilation/dfthcsos/arm2/plan.json
```

After the implementation reports the exact encoded delta width and fix-up qubit use, re-run with `--buffered-delta-bits-per-entry` and `--phase-fixup-qubits`. These are explicit inputs, not inferred defaults.

## Required compiler work that remains

1. Use the exact existing angle table/generator and hash all baseline members.
2. Implement Reed–Muller encoding of within-block angle deltas; keep `submission.npz`, Hamiltonian terms, factorization, lambda and all non-angle circuits unchanged for this arm.
3. Define the exact phase-fixup circuit for the X-basis-measured buffer; prove lookup equivalence for all 3,976 legal addresses and verify input restoration, scratch cleanup and phase behavior under measurement outcomes.
4. Compile every `angle_k_*.kmb`; record peak qubits and Toffoli-like gate counts; reject any angle circuit over 128 qubits.
5. Run the unchanged complete official DFTHCSOS verifier (same contract/configuration as baseline). Record `lambda_eff`, `Q_total`, `T_total`, exact score, the artifact and source-member SHA-256 hashes, and verifier status.
6. Keep Arm 1 SelectSwap disabled and no additional transformation enabled. Only after Arm 2 has its own verified receipt may it be considered for composition with any other arm.

## Receipt envelope for audit

The auditor expects each JSON file to contain both an `official_receipt` object (the untouched verifier output) and an `experiment_manifest` object with:

- `arm`: exactly `arm2_reed_muller_angle_buffering_only`
- `arm1_selectswap_enabled`: `false`
- `other_transformations_enabled`: `[]`
- `input_npz_unchanged`: `true` and the exact `submission_npz_sha256`
- `source_members_sha256`: map of unchanged input/member names to SHA-256 hashes
- `lookup_semantics_pass` and `phase_semantics_pass`: `true`
- `angle_subcircuits`: each angle circuit name, SHA-256, measured `num_qubits`, and semantics test flags

The auditor verifies receipt score arithmetic `score = lambda_eff * Q_total * T_total`, strict improvement, manifest consistency, and the 128-qubit per-ANGLE cap. These manifest fields are audit assertions, not cryptographic proof of semantics; retain test output and the untouched verifier logs alongside each receipt.

```bash
python scripts/audit_dfthcsos_arm2_receipts.py \
  --baseline artifacts/quantum_compilation/dfthcsos/arm2/baseline_wrapper.json \
  --candidate artifacts/quantum_compilation/dfthcsos/arm2/candidate_wrapper.json \
  --output artifacts/quantum_compilation/dfthcsos/arm2/audit.json
```

## Status

Planning and offline tests only. The exact circuit transformation and official chemistry-verifier run are not performed by this package. No cost reduction is claimed until the actual candidate receipt passes the unchanged official verifier and its score beats `3355599588.3155365` under the same contract.
