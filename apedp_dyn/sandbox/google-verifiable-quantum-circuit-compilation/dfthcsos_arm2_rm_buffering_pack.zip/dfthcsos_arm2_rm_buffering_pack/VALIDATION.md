# Validation boundaries

The tests cover candidate-layout bookkeeping, refusal to guess unknown widths, cap screening once widths are supplied, score arithmetic, manifest isolation, and promotion gating. They do not call Kickmix, compile an ANGLE circuit, independently prove Reed–Muller phase correction, or run the official DFTHCSOS verifier.
