#!/usr/bin/env python3
"""Test register/cache layouts for the supplied direct-polynomial phase compiler.

The helper directory must contain direct_phase.py, recycled.py, low_memory_adder.py and
selected_coefficients.csv exported from the Direct Phases notebook. This runner does not
invent or silently fit a replacement coefficient table.
"""
from __future__ import annotations
import argparse, gc, hashlib, importlib, json, math, os, sys, time
from pathlib import Path
import numpy as np

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--competition-root',default=os.environ.get('QCOMP_ROOT'))
    p.add_argument('--helper-dir',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('artifacts/direct_poly_layouts'))
    p.add_argument('--full-verifications',type=int,default=1)
    p.add_argument('--cache-values',type=int,nargs='*',default=[0,4,8,12,16])
    p.add_argument('--include-reused-zero',action='store_true')
    a=p.parse_args()
    if not a.competition_root:p.error('Set QCOMP_ROOT or --competition-root')
    root=Path(a.competition_root).resolve(); helpers=a.helper_dir.resolve(); out=a.output
    for f in ['direct_phase.py','recycled.py','low_memory_adder.py','selected_coefficients.csv']:
        if not (helpers/f).exists():raise FileNotFoundError(f'Missing {helpers/f}; export the helper cell from the notebook first.')
    sys.path[:0]=[str(root/'kickmix'),str(root/'verifiers'),str(helpers)]
    import kickmix as km
    from invsqrt import verify_submission_invsqrt as iv
    for name in ['direct_phase','recycled','low_memory_adder']:
        sys.modules.pop(name,None)
    import direct_phase as dp
    index_bits,fractions=9,(27,20,12)
    tables=np.loadtxt(helpers/'selected_coefficients.csv',delimiter=',',dtype=np.int64)
    if tables.shape!=(1<<index_bits,len(fractions)) or (tables<0).any():
        raise ValueError(f'Coefficient table shape/range mismatch: {tables.shape}')
    original=dp.coefficient_tables
    def pinned_tables(k,fs):
        return tables if (k==index_bits and tuple(fs)==fractions) else original(k,fs)
    dp.coefficient_tables=pinned_tables
    sys.modules.pop('recycled',None)
    from recycled import build_circuit_recycled
    from direct_phase import exact_model_check,fixed_point_model
    spec=iv.ProblemSpecInvSqrt.for_n_p(10)
    certificate=exact_model_check(index_bits,fractions,max_x=spec.max_x)
    if not certificate.get('pass'):
        raise RuntimeError(f'Full-domain integer certificate rejected table: {certificate}')
    out.mkdir(parents=True,exist_ok=True)
    cache_values=list(a.cache_values)
    if a.include_reused_zero:cache_values.append(None)
    rows=[]; candidate_paths=[]
    # Spot-check circuit/model equivalence, with edge points and normalization boundaries.
    rng=np.random.default_rng(20261023)
    edge=[1,2,3,spec.max_x]
    edge += [x for k in range(1,22) for x in (2**k-1,2**k,2**k+1) if 1<=x<=spec.max_x]
    for idx,cache in enumerate(cache_values):
        circ=build_circuit_recycled(index_bits,fractions,tables=tables,compressed_flags=True,
             builtin_lookup=True,shrink_coefficients=True,reused_zero_products=(cache is None),cached_products=cache)
        stats=circ.operation_statistics(); rotations=int(stats.num_z_pow(min_clifford_hierarchy_level=4))
        epsilon=math.pi*(certificate['min_margin_units']/2**64)/max(rotations,1)
        t_count=1+rotations*(0.56*math.log2(1/epsilon)+5.3)
        estimate=float(circ.num_qubits*(stats.num_toffoli_like+t_count/4.0))
        path=out/f'layout_{idx:02d}_cache_{cache}.kmb';circ.to_file(str(path),format='kmb')
        q,scratch=iv.validate_registers(circ,spec);sim=km.Simulator(batch_size=256,seed=20261023,debug_print=False)
        checks=0
        for batch in range(32):
            xs=rng.integers(1,spec.max_x+1,256,dtype=np.uint64)
            if batch==0:xs[:len(edge)]=edge
            sim.clear_for_shot();sim.write_across_shots(q,iv.to_bits(xs,spec.width));sim.do(circ)
            if not np.array_equal(iv.from_bits(sim.read_across_shots(q)),xs):raise AssertionError('Input restoration failed')
            if sim.read_across_shots(scratch).any():raise AssertionError('Scratch is not clean')
            phase=np.array([iv.half_turns_to_units(sim.read_shot_phase(j)) for j in range(256)],dtype=np.uint64)
            model=fixed_point_model(xs,index_bits,fractions).astype(np.uint64)<<np.uint64(64-fractions[0]-10)
            if not np.array_equal(phase,model):raise AssertionError(f'Circuit/model mismatch for cache={cache}')
            checks+=len(xs)
        row={'cache_products':cache,'qubits':circ.num_qubits,'toffoli_like':int(stats.num_toffoli_like),
             'rotations':rotations,'estimated_cost':estimate,'spot_checks':checks,
             'artifact':str(path),'artifact_sha256':sha256(path),'screen':'PASS'}
        rows.append(row);candidate_paths.append((estimate,path,row))
        print(json.dumps({k:row[k] for k in ['cache_products','qubits','toffoli_like','rotations','estimated_cost','screen']}),flush=True)
        del sim,circ;gc.collect()
    rows.sort(key=lambda x:x['estimated_cost']);(out/'layout_screen.json').write_text(json.dumps({'certificate':certificate,'rows':rows},indent=2))
    full_attempts=0
    for estimate,path,row in sorted(candidate_paths,key=lambda x:x[0]):
        if full_attempts>=a.full_verifications:break
        full_attempts += 1
        circ=km.Circuit.from_file(str(path));started=time.monotonic()
        try:
            report=iv.verify(circ,spec)
        except Exception as exc:
            report={'status':'ERROR','error':repr(exc)}
        row['official_verification']=report;row['full_verification_seconds']=time.monotonic()-started
        row['verified_score']=report.get('score')
        row['verified_status']=report.get('status')
        if report.get('status')!='PASS': print('Full verifier rejected/errored on layout; not promoted.',flush=True)
        print(json.dumps({'cache_products':row['cache_products'],'status':report.get('status'),'score':report.get('score')}),flush=True)
    (out/'layout_screen.json').write_text(json.dumps({'certificate':certificate,'rows':rows},indent=2))
    print(f'Full verifier runs: {full_attempts}; output: {out.resolve()}')

if __name__=='__main__':main()
