"""Piecewise-linear QROM seed for the benchmark's reversible inverse-square-root circuit.

Adapted from the user's supplied "Verified circuit quick wins" / "Verifier-Guided" notebook.
Requires the competition's kickmix extension and verifiers on PYTHONPATH.
"""
from __future__ import annotations
import dataclasses
import functools
import numpy as np
import kickmix as km
from invsqrt import nr_reference_circuit as ref

@dataclasses.dataclass(frozen=True)
class QPrecision:
    index_bits: int = 7
    coef_bits: int = 16
    slope_bits: int = 12
    delta_bits: int = 10
    square_bits: int = 28
    product_bits: int = 27
    result_bits: int = 28
    def output_bits(self, n_p: int) -> int:
        return self.result_bits + n_p + 1

@functools.lru_cache(maxsize=None)
def line_table(n_p: int, prec: QPrecision):
    k, wc, wb = prec.index_bits, prec.coef_bits, prec.slope_bits
    a_tab, b_tab = [0] * (1 << k), [0] * (1 << k)
    for i in range(1 << (k - 2), 1 << k):
        m0, m1 = i / 2 ** (k - 2), (i + 1) / 2 ** (k - 2)
        slope = (m0 ** -0.5 - m1 ** -0.5) / (m1 - m0)
        ms = np.linspace(m0, m1, 4097)
        gap = float((m0 ** -0.5 - slope * (ms - m0) - ms ** -0.5).max())
        a_tab[i] = round((m0 ** -0.5 - gap / 2) * 2 ** wc)
        b_tab[i] = round(slope * 2 ** wb)
    return tuple(a_tab), tuple(b_tab)

def _delta_rows(n_p: int, prec: QPrecision):
    width, k = 2 * n_p + 2, prec.index_bits
    rows = []
    for j in range(1, prec.delta_bits + 1):
        bit = width - k - j
        if bit < 0: break
        rows.append((bit, prec.coef_bits - prec.slope_bits - (k - 2 + j)))
    return rows

def fixed_point_model(n_p: int, prec: QPrecision, xs: np.ndarray) -> np.ndarray:
    width, wc, wsq, wz, wp = 2*n_p+2, prec.coef_bits, prec.square_bits, prec.product_bits, prec.result_bits
    xs = np.asarray(xs, dtype=np.int64)
    if (xs <= 0).any(): raise ValueError("Inputs must be positive")
    def bit(v, i): return (v >> i) & 1
    def product(rows, operand, out_bits, operand_bits, limit):
        acc = np.zeros_like(xs)
        for ctl, weight in rows:
            e = out_bits - operand_bits + weight
            acc += ctl * (operand << e if e >= 0 else operand >> -e)
        if (acc >= 2**limit).any(): raise OverflowError("Intermediate register overflow")
        return acc
    s = (width - (np.floor(np.log2(xs)).astype(np.int64) + 1)) // 2
    x_norm = xs << (2*s)
    a_tab, b_tab = (np.asarray(t, dtype=np.int64) for t in line_table(n_p, prec))
    index = x_norm >> (width - prec.index_bits)
    b, y0 = b_tab[index], a_tab[index].copy()
    for row_bit, shift in _delta_rows(n_p, prec):
        y0 -= bit(x_norm, row_bit) * (b << shift if shift >= 0 else b >> -shift)
    if ((y0 <= 0) | (y0 >= 2**wc)).any(): raise OverflowError("y0 does not fit its register")
    y = {k: bit(y0, wc-k) for k in range(1, wc+1)}
    square = np.zeros_like(xs)
    for k in range(1, wc+1):
        if 2*k <= wsq: square += y[k] << (wsq-2*k)
        for l in range(k+1, wc+1):
            if k+l-1 <= wsq: square += (y[k] & y[l]) << (wsq-(k+l-1))
    m_rows = [(bit(x_norm, i), i-width+2) for i in range(width)]
    z = product(m_rows, square, wz, wsq, wz+2)
    correction = (3 << wz)-z
    p = product([(y[k], -k) for k in range(1, wc+1)], correction, wp, wz, wp+1)
    return p << s

def _lookup(builder, n_p, prec, x, ancillas, y0, breg):
    width, k = 2*n_p+2, prec.index_bits
    a_tab, b_tab = line_table(n_p, prec)
    bits = [x[width-1-level] for level in range(k)]
    first = 1 << (k-2)
    def load(row, control):
        for reg, value in ((y0, a_tab[row]), (breg, b_tab[row])):
            for t in range(len(reg)):
                if (value >> t) & 1: builder.cx(control, reg[t])
    def node(control, level, lo, hi):
        if hi <= first: return
        valid = max(lo, first)
        if hi-valid == 1 or all(a_tab[r] == a_tab[valid] and b_tab[r] == b_tab[valid] for r in range(valid, hi)):
            load(valid, control); return
        mid = (lo+hi)//2
        bit, ancilla = bits[level], ancillas[level-1]
        if mid <= first:
            builder.init_and(control, bit, ancilla); node(ancilla, level+1, mid, hi); builder.del_and(control, bit, ancilla); return
        builder.x(bit); builder.init_and(control, bit, ancilla); builder.x(bit)
        node(ancilla, level+1, lo, mid); builder.cx(control, ancilla)
        node(ancilla, level+1, mid, hi); builder.del_and(control, bit, ancilla)
    half = 1 << (k-1)
    builder.x(bits[0]); node(bits[0], 1, 0, half)
    builder.x(bits[0]); node(bits[0], 1, half, 2*half)

def _linear(builder, inverse, n_p, prec, x, breg, y0, scratch):
    width = 2*n_p+2
    for row_bit, shift in _delta_rows(n_p, prec):
        terms = [(breg[t], t+shift) for t in range(len(breg)) if 0 <= t+shift < len(y0)]
        if terms: ref._add_row(builder, inverse, x[row_bit], terms, y0, scratch, subtract=True)

def build_circuit(n_p: int, prec: QPrecision = QPrecision()):
    width, out_bits = 2*n_p+2, prec.output_bits(n_p)
    builder = km.CircuitBuilder()
    x = builder.create_quantum_register(width, name="x")
    y1 = builder.alloc_qubits(out_bits); flags = builder.alloc_qubits(n_p)
    y0 = builder.alloc_qubits(prec.coef_bits); breg = builder.alloc_qubits(prec.slope_bits)
    square = builder.alloc_qubits(prec.square_bits); z = builder.alloc_qubits(prec.product_bits+2)
    scratch = builder.alloc_qubits(max(prec.square_bits, prec.product_bits+2, prec.result_bits+1, prec.coef_bits, prec.index_bits-1))
    p = y1[:len(y1)-len(flags)]; ancillas = scratch[:prec.index_bits-1]
    def compute(inverse):
        stages = [
            ("normalize", lambda inv: ref._normalize(builder, inv, x, flags)),
            ("lookup", lambda inv: _lookup(builder, n_p, prec, x, ancillas, y0, breg)),
            ("linear", lambda inv: _linear(builder, inv, n_p, prec, x, breg, y0, scratch)),
            ("square", lambda inv: ref._square(builder, inv, y0, square, scratch)),
            ("multiply_m", lambda inv: ref._multiply_m(builder, inv, x, square, z, scratch)),
            ("correct", lambda inv: ref._correct(builder, inv, z)),
            ("multiply_y0", lambda inv: ref._multiply_y0(builder, inv, y0, z, p, scratch)),
            ("denormalize", lambda inv: ref._denormalize(builder, inv, flags, y1)),
        ]
        for name, fn in (reversed(stages) if inverse else stages):
            with builder.mark(name): fn(inverse)
    compute(False); ref._phase_by_bits(builder, y1); compute(True)
    for reg in (y1, flags, y0, breg, square, z, scratch): builder.free(reg)
    return builder.finish_circuit()
