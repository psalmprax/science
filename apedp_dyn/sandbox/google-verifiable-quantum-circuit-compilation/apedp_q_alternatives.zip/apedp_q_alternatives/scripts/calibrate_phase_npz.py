#!/usr/bin/env python3
"""Solve the phase-angle correction LP from exported error/contribution arrays.

Input NPZ arrays:
  signed_errors: shape (N,), error before correction in phase turns
  contribution_bits: shape (N, R), 0/1 phase contribution of each retained rotation
  tolerances: shape (N,), allowed absolute error per input

The output is a calibration proposal only. The caller must apply corrections to the circuit,
quantize exactly as the circuit compiler does, exhaustively recheck the domain, and run the
official verifier before accepting it.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from apedp_q.phase_calibration import calibrate_phase_angles

def main():
    p=argparse.ArgumentParser()
    p.add_argument('arrays',type=Path,help='NPZ with signed_errors, contribution_bits, tolerances')
    p.add_argument('--out',type=Path,default=Path('phase_calibration_proposal.json'))
    p.add_argument('--max-correction',type=float,default=2*2.0**-36)
    p.add_argument('--quantization-step',type=float,default=2.0**-64)
    a=p.parse_args()
    with np.load(a.arrays,allow_pickle=False) as data:
        result=calibrate_phase_angles(data['signed_errors'],data['contribution_bits'],data['tolerances'],
          max_abs_correction=a.max_correction,quantization_step=a.quantization_step)
    report={**result.__dict__,'input_npz_sha256':hashlib.sha256(a.arrays.read_bytes()).hexdigest(),
            'official_verification':'NOT_RUN','status_is_not_a_circuit_PASS':True}
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    if not result.passed_all_constraints:raise SystemExit(2)

if __name__=='__main__':
    main()
