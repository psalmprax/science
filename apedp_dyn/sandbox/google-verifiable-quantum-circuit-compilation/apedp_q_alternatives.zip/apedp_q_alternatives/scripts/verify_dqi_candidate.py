#!/usr/bin/env python3
"""Run the official DQI verifier on an existing compiled candidate.

This is a verification adapter, not a DQI circuit generator. A replacement decoder must
implement the dynamic E0..E4094 mask contract before it is eligible here.
"""
from __future__ import annotations
import argparse, hashlib, json, os, sys, time
from pathlib import Path

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', type=Path, help='compiled .kmb circuit')
    parser.add_argument('--competition-root', default=os.environ.get('QCOMP_ROOT'))
    parser.add_argument('--shots', type=int, default=102400)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--out', type=Path, default=Path('dqi_verification.json'))
    args = parser.parse_args()
    if not args.competition_root: parser.error('Set QCOMP_ROOT or --competition-root')
    root = Path(args.competition_root).resolve()
    sys.path.insert(0, str(root/'kickmix')); sys.path.insert(0, str(root/'verifiers'))
    import kickmix as km
    from dqi import verify_submission_dqi as dv
    circuit = km.Circuit.from_file(str(args.candidate))
    spec = dv.ProblemSpecDQI.benchmark_instance(num_shots=args.shots)
    started = time.monotonic()
    report = dv.verify(circuit, spec, max_workers=args.workers)
    report = dict(report)
    report['artifact_sha256'] = sha256(args.candidate)
    report['verification_seconds'] = time.monotonic()-started
    report['authoritative_verifier_path'] = str(Path(dv.__file__).resolve())
    report['scope'] = 'official_dqi_verifier'
    report['dynamic_mask_contract_note'] = 'Verify that the candidate handles E0..E4094 per shot; the verifier PASS is the acceptance gate.'
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps(report, indent=2, default=str))
    if report.get('status') != 'PASS': raise SystemExit(2)

if __name__ == '__main__': main()
