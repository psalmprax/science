#!/usr/bin/env python3
"""Build/verify a controlled DFTHCSOS batch-size sweep with the supplied starter kit.

This explores a structural baseline, not a novel chemistry factorization. It intentionally
runs the official task verifier per completed build and records failures rather than hiding them.
"""
from __future__ import annotations
import argparse, json, os, subprocess, sys, time
from pathlib import Path

def run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--competition-root', default=os.environ.get('QCOMP_ROOT'))
    p.add_argument('--starter-kit', default=os.environ.get('QCOMP_STARTER_KIT'))
    p.add_argument('--output', type=Path, default=Path('artifacts/dfthcsos_batch_sweep'))
    p.add_argument('--brot', type=int, default=12)
    p.add_argument('--tree', default='log_depth')
    p.add_argument('--batch-sizes', type=int, nargs='+', default=[6,7,8,9])
    p.add_argument('--dataset', default='FeMoCo76o113e')
    a = p.parse_args()
    if not a.competition_root or not a.starter_kit:
        p.error('Set QCOMP_ROOT and QCOMP_STARTER_KIT, or pass the corresponding options.')
    comp, kit = Path(a.competition_root).resolve(), Path(a.starter_kit).resolve()
    build = kit/'starter/task3_circuits/build_circuits.py'
    verifier = comp/'verifiers/dfthcsos/verify.py'
    if not build.exists() or not verifier.exists(): raise FileNotFoundError('Starter builder or official verifier not found')
    a.output.mkdir(parents=True, exist_ok=True)
    records=[]
    for batch in a.batch_sizes:
        out=a.output/f'J{batch}'
        if out.exists():
            # Do not let a stale candidate be mistaken for a fresh build.
            import shutil; shutil.rmtree(out)
        start=time.monotonic()
        build_cmd=[sys.executable,str(build),a.dataset,'--tree',a.tree,'--brot',str(a.brot),'--batch-size',str(batch),'--output',str(out)]
        built=run(build_cmd)
        row={'batch_size':batch,'build_command':build_cmd,'build_returncode':built.returncode,'build_log':built.stdout}
        if built.returncode != 0:
            row.update({'status':'BUILD_FAILED','elapsed_seconds':time.monotonic()-start})
            records.append(row); print(json.dumps(row), flush=True); continue
        verified=run([sys.executable,str(verifier),str(out)])
        row['verifier_log']=verified.stdout
        row['verifier_returncode']=verified.returncode
        try: report=json.loads(verified.stdout)
        except json.JSONDecodeError: report={'status':'UNPARSEABLE_VERIFIER_OUTPUT','raw':verified.stdout}
        row['verifier_report']=report
        row['status']=report.get('status','UNKNOWN') if verified.returncode == 0 else 'VERIFIER_FAILED'
        row['elapsed_seconds']=time.monotonic()-start
        records.append(row)
        (a.output/'batch_sweep.json').write_text(json.dumps(records,indent=2,default=str))
        print(json.dumps({'batch_size':batch,'status':row['status'],'score':report.get('score'),'elapsed_seconds':row['elapsed_seconds']}),flush=True)
    (a.output/'batch_sweep.json').write_text(json.dumps(records,indent=2,default=str))

if __name__ == '__main__': main()
