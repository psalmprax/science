#!/usr/bin/env python3
"""Adapter for the ensemble-rotation/compression helpers from the supplied notebook.

Requires exported rotate_ensemble.py, chemistry_runner.py, tune_identity.py and
ensemble_compression.py, plus a source dfthcsos circuit folder containing submission.npz
and the matching angle_k_* files. Every selected candidate is passed to the official verifier.
"""
from __future__ import annotations
import argparse, os, sys, json
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--competition-root',default=os.environ.get('QCOMP_ROOT'))
    p.add_argument('--helper-dir',type=Path,required=True)
    p.add_argument('--source-dfthcsos',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('artifacts/chemistry_ensemble'))
    p.add_argument('--sweeps',type=int,default=25)
    p.add_argument('--counts',type=int,nargs='+',default=[44,46,48,50,52,54])
    a=p.parse_args()
    if not a.competition_root:p.error('Set QCOMP_ROOT or --competition-root')
    for f in ['rotate_ensemble.py','chemistry_runner.py','tune_identity.py','ensemble_compression.py']:
        if not (a.helper_dir/f).exists():raise FileNotFoundError(f'Export {f} from the supplied notebook first.')
    root=Path(a.competition_root).resolve();helpers=a.helper_dir.resolve();source=a.source_dfthcsos.resolve();out=a.output.resolve()
    sys.path[:0]=[str(root/'kickmix'),str(root/'verifiers'),str(helpers)]
    import kickmix  # noqa: F401
    from chemistry_runner import run_rotation
    from ensemble_compression import screen_truncations
    out.mkdir(parents=True,exist_ok=True)
    rotated=out/'rotated'
    rotation_report=run_rotation(source,output=rotated,sweeps=a.sweeps)
    compression_report=screen_truncations(rotated,rotation_report['after'],output=out/'compression',counts=tuple(a.counts))
    result={'rotation':rotation_report,'compression':compression_report}
    (out/'result.json').write_text(json.dumps(result,indent=2,default=str))
    print(json.dumps({'rotation_before':rotation_report['before'].get('score'),
                      'rotation_after':rotation_report['after'].get('score'),
                      'compression_selected':compression_report.get('selected'),
                      'result_path':str((out/'result.json').resolve())},indent=2))

if __name__=='__main__':main()
