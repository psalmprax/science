#!/usr/bin/env python3
"""Run a bounded QROM seed precision sweep against the official inverse-square-root verifier.

Example:
  QCOMP_ROOT=/kaggle/input/competitions/google-verifiable-quantum-circuit-compilation \\
    python scripts/run_invsqrt_qrom_sweep.py --output artifacts/qrom_sweep

This script requires the competition's kickmix extension and verifier package. Full verification is
expensive; --max-full-verifications defaults to 2 to cap accidental compute use.
"""
from __future__ import annotations
import argparse, hashlib, json, math, os, sys, time
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

def setup_competition(root: Path):
    sys.path.insert(0, str(root / "kickmix"))
    sys.path.insert(0, str(root / "verifiers"))
    if str(root / "kickmix") not in sys.path:
        raise RuntimeError("kickmix path could not be configured")
    import kickmix  # noqa: F401
    from invsqrt import verify_submission_invsqrt
    return verify_submission_invsqrt

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--competition-root", default=os.environ.get("QCOMP_ROOT"))
    ap.add_argument("--output", default="artifacts/qrom_sweep")
    ap.add_argument("--max-full-verifications", type=int, default=2)
    args = ap.parse_args()
    if not args.competition_root:
        ap.error("Set QCOMP_ROOT or pass --competition-root")
    root, out = Path(args.competition_root).resolve(), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    verifier = setup_competition(root)
    from nr_qrom import QPrecision, build_circuit, fixed_point_model
    spec = verifier.ProblemSpecInvSqrt.for_n_p(10)
    xs = np.arange(1, spec.max_x + 1, dtype=np.int64)
    exact = 1.0 / np.sqrt(xs.astype(np.float64))
    tolerance = (2.0**-24) * exact
    # Width tuple: index, coefficient, slope, delta, square, product, result.
    configs = [
        (6,18,13,13,28,27,28), (6,18,12,12,28,27,28),
        (7,15,12,11,28,27,28), (7,15,13,12,28,27,28),
        (7,16,12,10,28,27,28), (7,16,11,11,28,27,27),
        (7,16,12,11,28,27,27), (7,16,12,11,28,27,28),
        (7,16,12,12,28,27,27), (7,16,12,12,28,27,28),
        (7,17,12,12,28,27,28), (7,16,12,11,27,26,28),
        (7,17,12,11,28,27,28), (8,18,13,12,29,28,29),
        (8,18,13,12,30,29,30),
    ]
    rows = []
    for cid, v in enumerate(configs):
        prec = QPrecision(index_bits=v[0], coef_bits=v[1], slope_bits=v[2], delta_bits=v[3],
                          square_bits=v[4], product_bits=v[5], result_bits=v[6])
        try:
            approx = fixed_point_model(10, prec, xs) / 2.0**prec.output_bits(10)
            worst = float((np.abs(approx-exact)/tolerance).max())
            margin = float((tolerance-np.abs(approx-exact)).min())
        except (OverflowError, ValueError, IndexError) as exc:
            rows.append({"candidate_id": cid, "precision": vars(prec), "screen": "REJECTED", "reason": str(exc)})
            print(f"{cid}: screen reject: {exc}", flush=True); continue
        if not math.isfinite(worst) or worst >= 1:
            rows.append({"candidate_id": cid, "precision": vars(prec), "screen": "REJECTED", "worst_error_over_tolerance": worst})
            print(f"{cid}: accuracy reject, worst={worst:.6f}", flush=True); continue
        circuit = build_circuit(10, prec)
        stats = circuit.operation_statistics()
        rotations = int(stats.num_z_pow(min_clifford_hierarchy_level=4))
        eps = math.pi * margin / max(rotations, 1)
        t_count = 1 + rotations * verifier.rotation_t_count(eps)
        est = float(circuit.num_qubits * (stats.num_toffoli_like + t_count / 4.0))
        path = out / f"candidate_{cid:02d}.kmb"
        circuit.to_file(str(path), format="kmb")
        row = {"candidate_id": cid, "precision": vars(prec), "qubits": circuit.num_qubits,
               "toffoli_like": int(stats.num_toffoli_like), "rotations": rotations,
               "worst_error_over_tolerance": worst, "estimated_cost": est, "artifact": str(path),
               "artifact_sha256": sha256(path), "screen": "PASS"}
        rows.append(row)
        print(f"{cid}: screened PASS Q={circuit.num_qubits}, Toffoli={stats.num_toffoli_like}, est={est:,.1f}", flush=True)
        del circuit, approx
    passing = sorted((r for r in rows if r.get("screen") == "PASS"), key=lambda r: r["estimated_cost"])
    full_attempts = 0
    for row in passing:
        if full_attempts >= args.max_full_verifications: break
        full_attempts += 1
        import kickmix as km
        circuit = km.Circuit.from_file(row["artifact"])
        started = time.monotonic()
        try:
            report = verifier.verify(circuit, spec)
        except Exception as exc:
            row["full_verification"] = {"status": "ERROR", "error": repr(exc)}
            print(f"{row['candidate_id']}: verifier exception: {exc}", flush=True)
            continue
        row["full_verification"] = report
        row["full_verification_seconds"] = time.monotonic()-started
        if report.get("status") == "PASS":
            print(f"{row['candidate_id']}: FULL PASS score={report.get('score')}", flush=True)
        else:
            print(f"{row['candidate_id']}: FULL FAIL", flush=True)
        (out / "sweep_results.json").write_text(json.dumps(rows, indent=2, default=str))
    (out / "sweep_results.json").write_text(json.dumps(rows, indent=2, default=str))
    print(f"Saved {out / 'sweep_results.json'}; screened={len(rows)}, full verifier runs={full_attempts}")

if __name__ == "__main__": main()
