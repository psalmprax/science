#!/usr/bin/env python3
"""Calculate aggregate score from verified per-task costs; never confuses it with leaderboard score."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from apedp_q.costs import aggregate_score

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--reference',required=True,help='JSON list [invsqrt,dqi,dfthcsos]')
    p.add_argument('--candidate',required=True,help='JSON list [invsqrt,dqi,dfthcsos] from actual verifier reports')
    p.add_argument('--out',type=Path)
    a=p.parse_args();refs=json.loads(Path(a.reference).read_text());cands=json.loads(Path(a.candidate).read_text())
    score=aggregate_score(refs,cands)
    report={'reference_costs':refs,'candidate_costs':cands,'aggregate_score_projection':score,
            'warning':'This is a cost-derived projection, not an official Kaggle score. Confirm every cost belongs to the exact assembled artifacts.'}
    text=json.dumps(report,indent=2);print(text)
    if a.out:a.out.write_text(text+'\n')
if __name__=='__main__':main()
