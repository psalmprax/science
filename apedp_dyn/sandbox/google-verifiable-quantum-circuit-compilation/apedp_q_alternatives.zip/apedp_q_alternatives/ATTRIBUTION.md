# Attribution and scope

This scaffold implements orchestration and small research utilities based on the designs and code excerpts the user supplied in conversation.

- The piecewise-linear inverse-square-root seed (`scripts/nr_qrom.py`) is adapted from the user's excerpts of the public Kaggle notebook *Verified circuit quick wins* and *Verifier-Guided Quantum Circuit Optimization*. Preserve and confirm the upstream Apache-2.0 license and attribution before redistributing copied/upstream components.
- The direct-polynomial compiler and chemistry rotation/compression runners intentionally require helper files exported from the user's supplied *Direct Phases and Smaller Ensembles* notebook. Those upstream helpers are not bundled here.
- The DQI script is only an adapter to the official verifier; it does not claim to implement or own a new Reed–Solomon decoder.
- The phase-calibration helper solves a mathematical linear program and does not alter compiled circuits by itself.
- No competition data, binary `kickmix` extension, official verifier code, compiled submissions, or private/secret salts are included.

The scaffold itself is not represented as an official competition submission or as a reproduction of any reported Kaggle score. Exact contract and artifact hashes must be generated in the user's environment before experiments are promoted.
