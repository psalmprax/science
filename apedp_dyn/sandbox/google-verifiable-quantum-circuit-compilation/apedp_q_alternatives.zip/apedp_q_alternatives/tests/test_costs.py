import math
import pytest
from apedp_q.costs import aggregate_score, chemistry_cost, dqi_cost, invsqrt_cost


def test_invsqrt_cost():
    assert invsqrt_cost(10, 100, 40) == 1100


def test_other_costs():
    assert dqi_cost(1.2, 10, 100) == pytest.approx(12000)
    assert chemistry_cost(5, 10, 100) == 5000


def test_score_reference_is_one():
    ref = [10, 20, 30]
    assert aggregate_score(ref, ref) == pytest.approx(1.0)


def test_invalid_cost_rejected():
    with pytest.raises(ValueError):
        aggregate_score([1, 2], [1, 2])
