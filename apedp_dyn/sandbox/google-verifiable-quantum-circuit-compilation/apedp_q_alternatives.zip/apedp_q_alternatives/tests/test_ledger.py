from apedp_q.models import CandidateSpec, CandidateResult, CandidateState, VerifierReceipt
from apedp_q.ledger import AppendOnlyLedger


def test_ledger_requires_matching_authoritative_receipt(tmp_path):
    spec=CandidateSpec('invsqrt','unit-test',{'delta':10},'a'*64)
    ledger=AppendOnlyLedger(tmp_path/'ledger.jsonl')
    result=CandidateResult(spec,CandidateState.UNVERIFIED,artifact_sha256='b'*64,measured_cost=9)
    result.verifier_receipt=VerifierReceipt('PASS','full-domain','c'*64,9,10,True,'test')
    assert not ledger.promote_if_better(result,10)
    assert result.state == CandidateState.UNRESOLVED


def test_ledger_promotes_verified_lower_cost(tmp_path):
    spec=CandidateSpec('invsqrt','unit-test',{'delta':10},'a'*64)
    ledger=AppendOnlyLedger(tmp_path/'ledger.jsonl')
    result=CandidateResult(spec,CandidateState.UNVERIFIED,artifact_sha256='b'*64,measured_cost=9)
    result.verifier_receipt=VerifierReceipt('PASS','full-domain','b'*64,9,10,True,'test')
    assert ledger.promote_if_better(result,10)
    assert result.state == CandidateState.VERIFIED_IMPROVEMENT
