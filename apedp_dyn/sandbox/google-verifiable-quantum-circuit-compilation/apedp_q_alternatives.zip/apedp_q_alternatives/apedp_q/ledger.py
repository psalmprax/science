from __future__ import annotations
import json
import math
import os
from pathlib import Path
from typing import Any
from .models import CandidateResult, CandidateState


class AppendOnlyLedger:
    """JSONL audit ledger. It never silently overwrites an earlier experiment."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, event: str, payload: dict[str, Any]) -> None:
        record = {"event": event, "payload": payload}
        encoded = json.dumps(record, sort_keys=True, separators=(",", ":"), default=str)
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(encoded + "\n")
            stream.flush()
            os.fsync(stream.fileno())

    def record_result(self, result: CandidateResult) -> None:
        self.append("candidate_result", result.to_dict())

    def promote_if_better(self, result: CandidateResult, incumbent_cost: float) -> bool:
        """Promote only a passing authoritative receipt and a strictly lower measured cost."""
        receipt = result.verifier_receipt
        if receipt is None or not receipt.passed:
            result.state = CandidateState.INSUFFICIENT_EVIDENCE if receipt is None else CandidateState.VERIFIER_FAILED
            result.rejection_reason = "Promotion requires an authoritative PASS receipt."
            self.record_result(result)
            return False
        if not result.artifact_sha256 or receipt.artifact_sha256 != result.artifact_sha256:
            result.state = CandidateState.UNRESOLVED
            result.rejection_reason = "Artifact hash differs from verifier receipt."
            self.record_result(result)
            return False
        if result.measured_cost is None or not math.isfinite(result.measured_cost) or not (result.measured_cost > 0):
            result.state = CandidateState.UNRESOLVED
            result.rejection_reason = "Promotion requires a positive measured cost."
            self.record_result(result)
            return False
        if receipt.score is not None and not math.isclose(result.measured_cost, receipt.score, rel_tol=1e-9, abs_tol=1e-12):
            result.state = CandidateState.UNRESOLVED
            result.rejection_reason = "Candidate measured cost does not match verifier receipt score."
            self.record_result(result)
            return False
        if result.measured_cost < incumbent_cost:
            result.state = CandidateState.VERIFIED_IMPROVEMENT
            result.rejection_reason = None
            self.record_result(result)
            self.append("incumbent_promoted", {
                "candidate_id": result.spec.candidate_id,
                "artifact_sha256": result.artifact_sha256,
                "previous_cost": incumbent_cost,
                "new_cost": result.measured_cost,
                "scope": receipt.scope,
            })
            return True
        result.state = CandidateState.VERIFIED_NONIMPROVING
        result.rejection_reason = "Verified cost did not beat the incumbent."
        self.record_result(result)
        return False
