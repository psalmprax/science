"""APEDP-Q research scaffolding: candidate tracking, cost models and verifier adapters."""
__version__ = "0.1.0"
