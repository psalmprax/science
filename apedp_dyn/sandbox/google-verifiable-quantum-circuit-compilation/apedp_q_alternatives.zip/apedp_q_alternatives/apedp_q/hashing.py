from __future__ import annotations
import hashlib
from pathlib import Path


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_tree(root: str | Path, *, suffixes: tuple[str, ...] | None = None) -> str:
    root = Path(root)
    entries = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        if suffixes and path.suffix not in suffixes:
            continue
        entries.append((path.relative_to(root).as_posix(), sha256_file(path)))
    payload = "\n".join(f"{name}  {digest}" for name, digest in entries).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
