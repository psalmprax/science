from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any
import hashlib
import json


class CandidateState(str, Enum):
    PROPOSED = "PROPOSED"
    SCREEN_REJECTED = "SCREEN_REJECTED"
    UNVERIFIED = "UNVERIFIED"
    VERIFIER_FAILED = "VERIFIER_FAILED"
    VERIFIED_NONIMPROVING = "VERIFIED_NONIMPROVING"
    VERIFIED_IMPROVEMENT = "VERIFIED_IMPROVEMENT"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    UNRESOLVED = "UNRESOLVED"


@dataclass(frozen=True)
class CircuitContract:
    benchmark: str
    contract_sha256: str
    source_root: str
    cost_name: str
    expected_verifier: str
    metadata: dict[str, Any]

    def __post_init__(self) -> None:
        if self.benchmark not in {"invsqrt", "dqi", "dfthcsos"}:
            raise ValueError(f"Unknown benchmark: {self.benchmark}")
        if len(self.contract_sha256) != 64:
            raise ValueError("contract_sha256 must be a SHA-256 hex digest")


@dataclass(frozen=True)
class CandidateSpec:
    benchmark: str
    proposer: str
    parameters: dict[str, Any]
    contract_sha256: str

    @property
    def candidate_id(self) -> str:
        payload = {
            "benchmark": self.benchmark,
            "proposer": self.proposer,
            "parameters": self.parameters,
            "contract_sha256": self.contract_sha256,
        }
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:24]


@dataclass(frozen=True)
class VerifierReceipt:
    status: str
    scope: str
    artifact_sha256: str
    score: float | None
    verified_shots: int | None
    authoritative: bool
    verifier_version: str
    salt_id: str | None = None  # identifier only; never store the secret salt/token
    details: dict[str, Any] | None = None

    @property
    def passed(self) -> bool:
        return self.status.upper() == "PASS" and self.authoritative


@dataclass
class CandidateResult:
    spec: CandidateSpec
    state: CandidateState
    artifact_path: str | None = None
    artifact_sha256: str | None = None
    estimated_cost: float | None = None
    measured_cost: float | None = None
    verifier_receipt: VerifierReceipt | None = None
    rejection_reason: str | None = None
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["state"] = self.state.value
        return data
