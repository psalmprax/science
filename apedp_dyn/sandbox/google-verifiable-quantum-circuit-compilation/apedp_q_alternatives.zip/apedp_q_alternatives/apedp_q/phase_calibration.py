"""Constraint-based phase calibration helper.

The caller supplies signed base phase errors e[x], a binary contribution matrix B[x,j]
for retained rotations, per-input tolerances tau[x], correction bounds, and a quantization
step. This module optimizes corrections only; it does not edit/compile a Kickmix circuit.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class PhaseCalibrationResult:
    corrections: list[float]
    continuous_margin: float
    quantized_margin: float
    worst_error: float
    passed_all_constraints: bool
    status: str


def calibrate_phase_angles(
    signed_errors: np.ndarray,
    contribution_bits: np.ndarray,
    tolerances: np.ndarray,
    *,
    max_abs_correction: float = 2.0 * 2.0**-36,
    quantization_step: float = 2.0**-64,
) -> PhaseCalibrationResult:
    """Maximize common error margin with an LP, then recheck after quantization.

    Constraints for every row x:
        -tau[x] + m <= e[x] + B[x] @ delta <= tau[x] - m

    SciPy is imported lazily. Full-domain arrays can be large; callers should stream/build
    the constraints or use a sparse matrix for large problems.
    """
    e = np.asarray(signed_errors, dtype=np.float64).reshape(-1)
    b = np.asarray(contribution_bits, dtype=np.float64)
    tau = np.asarray(tolerances, dtype=np.float64).reshape(-1)
    if b.ndim != 2 or b.shape[0] != e.size or tau.size != e.size:
        raise ValueError("Expected B.shape == (n_inputs, n_rotations), e/tau length n_inputs")
    if not np.isfinite(e).all() or not np.isfinite(b).all() or not np.isfinite(tau).all():
        raise ValueError("Calibration inputs must be finite")
    if (tau <= 0).any() or max_abs_correction <= 0 or quantization_step <= 0:
        raise ValueError("Tolerances, correction bounds and quantization step must be positive")

    try:
        from scipy.optimize import linprog
    except ImportError as exc:
        raise RuntimeError("Install scipy to run phase calibration") from exc

    nrot = b.shape[1]
    # Variables are [delta_0, ..., delta_(nrot-1), margin].
    ones = np.ones((e.size, 1), dtype=np.float64)
    a_ub = np.vstack([np.hstack([b, ones]), np.hstack([-b, ones])])
    b_ub = np.concatenate([tau - e, tau + e])
    objective = np.zeros(nrot + 1, dtype=np.float64)
    objective[-1] = -1.0  # maximize the margin
    bounds = [(-max_abs_correction, max_abs_correction)] * nrot + [(0.0, None)]
    fit = linprog(objective, A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not fit.success:
        return PhaseCalibrationResult([], float("-inf"), float("-inf"), float("inf"), False,
                                      f"LP_INFEASIBLE: {fit.message}")
    continuous = fit.x[:nrot]
    quantized = np.rint(continuous / quantization_step) * quantization_step
    final_error = e + b @ quantized
    margins = tau - np.abs(final_error)
    qmargin = float(margins.min())
    return PhaseCalibrationResult(
        corrections=quantized.tolist(),
        continuous_margin=float(fit.x[-1]),
        quantized_margin=qmargin,
        worst_error=float(np.abs(final_error).max()),
        passed_all_constraints=bool(qmargin >= 0.0),
        status="PASS_AFTER_QUANTIZATION" if qmargin >= 0.0 else "FAIL_AFTER_QUANTIZATION",
    )
