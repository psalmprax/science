from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable
import math
from .hashing import sha256_file
from .ledger import AppendOnlyLedger
from .models import CandidateSpec, CandidateResult, CandidateState, CircuitContract, VerifierReceipt

@dataclass(frozen=True)
class ScreenDecision:
    accepted: bool
    reason: str = ""
    metadata: dict[str, Any] | None = None

@dataclass(frozen=True)
class DriverReport:
    candidate_id: str
    state: str
    artifact_path: str | None
    estimated_cost: float | None
    measured_cost: float | None
    promoted: bool
    reason: str | None

class ExperimentDriver:
    """Generic orchestration layer. Circuit generation and verification are injected adapters."""
    def __init__(self, ledger: AppendOnlyLedger):
        self.ledger = ledger

    def evaluate(
        self,
        spec: CandidateSpec,
        contract: CircuitContract,
        *,
        incumbent_cost: float,
        output_dir: str | Path,
        screen: Callable[[CandidateSpec, CircuitContract], ScreenDecision],
        compile_candidate: Callable[[CandidateSpec, CircuitContract, Path], Path],
        estimate_cost: Callable[[Path, CandidateSpec, CircuitContract], float],
        verify_candidate: Callable[[Path, CandidateSpec, CircuitContract], VerifierReceipt],
    ) -> DriverReport:
        if spec.benchmark != contract.benchmark or spec.contract_sha256 != contract.contract_sha256:
            result = CandidateResult(spec, CandidateState.UNRESOLVED, rejection_reason="Candidate/contract mismatch")
            self.ledger.record_result(result)
            return DriverReport(spec.candidate_id, result.state.value, None, None, None, False, result.rejection_reason)

        result = CandidateResult(spec, CandidateState.PROPOSED)
        self.ledger.record_result(result)
        decision = screen(spec, contract)
        if not decision.accepted:
            result.state = CandidateState.SCREEN_REJECTED
            result.rejection_reason = decision.reason or "Screen rejected candidate"
            result.metadata = decision.metadata
            self.ledger.record_result(result)
            return DriverReport(spec.candidate_id, result.state.value, None, None, None, False, result.rejection_reason)

        out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
        path = compile_candidate(spec, contract, out)
        if not path.is_file():
            result.state = CandidateState.UNRESOLVED
            result.rejection_reason = f"Compiler did not produce an artifact: {path}"
            self.ledger.record_result(result)
            return DriverReport(spec.candidate_id, result.state.value, str(path), None, None, False, result.rejection_reason)
        result.artifact_path = str(path)
        result.artifact_sha256 = sha256_file(path)
        estimated = estimate_cost(path, spec, contract)
        if not math.isfinite(estimated) or estimated <= 0:
            result.state = CandidateState.UNRESOLVED
            result.rejection_reason = "Estimator returned a non-finite/non-positive cost"
            result.estimated_cost = estimated
            self.ledger.record_result(result)
            return DriverReport(spec.candidate_id, result.state.value, str(path), estimated, None, False, result.rejection_reason)
        result.estimated_cost = float(estimated)
        receipt = verify_candidate(path, spec, contract)
        result.verifier_receipt = receipt
        result.measured_cost = receipt.score if receipt.passed else None
        result.metadata = decision.metadata
        promoted = self.ledger.promote_if_better(result, incumbent_cost)
        return DriverReport(spec.candidate_id, result.state.value, str(path), result.estimated_cost,
                            result.measured_cost, promoted, result.rejection_reason)
