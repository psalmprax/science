from __future__ import annotations
import math
from typing import Iterable


def invsqrt_cost(qubits: int, toffoli_like: float, t_count: float) -> float:
    """Competition cost: Q * (Toffoli-equivalents + synthesized T/4)."""
    if qubits <= 0 or toffoli_like < 0 or t_count < 0:
        raise ValueError("Resource counts must be nonnegative and qubits must be positive")
    return float(qubits * (toffoli_like + t_count / 4.0))


def dqi_cost(repetition_factor: float, qubits: int, mean_toffoli_like: float) -> float:
    """Competition form: R(epsilon+) * Q^2 * mean executed Toffoli-like gates."""
    if repetition_factor < 1 or qubits <= 0 or mean_toffoli_like < 0:
        raise ValueError("Invalid DQI resource values")
    return float(repetition_factor * qubits * qubits * mean_toffoli_like)


def chemistry_cost(lambda_eff: float, qubits: int, toffoli_like: float) -> float:
    """Competition form: lambda_eff * Q * T for the chemistry block-encoding."""
    if lambda_eff <= 0 or qubits <= 0 or toffoli_like < 0:
        raise ValueError("Invalid chemistry resource values")
    return float(lambda_eff * qubits * toffoli_like)


def aggregate_score(reference_costs: Iterable[float], candidate_costs: Iterable[float]) -> float:
    refs, cands = list(reference_costs), list(candidate_costs)
    if len(refs) != 3 or len(cands) != 3:
        raise ValueError("Expected exactly three task costs: invsqrt, dqi, dfthcsos")
    if any((not math.isfinite(x) or x <= 0) for x in refs + cands):
        raise ValueError("All reference and candidate costs must be finite and positive")
    return float(math.exp(sum(math.log(r / c) for r, c in zip(refs, cands)) / 3.0))


def relative_reduction(reference: float, candidate: float) -> float:
    if reference <= 0 or candidate <= 0:
        raise ValueError("Costs must be positive")
    return 1.0 - candidate / reference
