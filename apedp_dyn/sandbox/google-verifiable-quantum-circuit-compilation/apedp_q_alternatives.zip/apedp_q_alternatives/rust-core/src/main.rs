use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{env, fs, process};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
struct Precision {
    index_bits: u32,
    coef_bits: u32,
    slope_bits: u32,
    delta_bits: u32,
    square_bits: u32,
    product_bits: u32,
    result_bits: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ResourceCandidate {
    id: String,
    qubits: u64,
    toffoli_like: u64,
    t_count: u64,
    cost: f64,
}

fn fail(message: &str) -> ! {
    eprintln!("error: {message}");
    process::exit(2)
}

fn read_json(path: &str) -> Value {
    let bytes = fs::read(path).unwrap_or_else(|e| fail(&format!("cannot read {path}: {e}")));
    serde_json::from_slice(&bytes).unwrap_or_else(|e| fail(&format!("invalid JSON {path}: {e}")))
}

fn write_json(value: &Value) {
    println!("{}", serde_json::to_string_pretty(value).unwrap());
}

fn positive_triplet(value: &Value, name: &str) -> Vec<f64> {
    let values = value.as_array().unwrap_or_else(|| fail(&format!("{name} must be an array")));
    if values.len() != 3 { fail(&format!("{name} must contain three costs")); }
    values.iter().map(|x| {
        let n = x.as_f64().unwrap_or_else(|| fail(&format!("{name} entries must be numeric")));
        if !n.is_finite() || n <= 0.0 { fail(&format!("{name} costs must be finite and positive")); }
        n
    }).collect()
}

fn score_file(path: &str) {
    let input = read_json(path);
    let refs = positive_triplet(&input["reference_costs"], "reference_costs");
    let costs = positive_triplet(&input["candidate_costs"], "candidate_costs");
    let log_sum: f64 = refs.iter().zip(costs.iter()).map(|(r,c)| (r/c).ln()).sum();
    let score = (log_sum / 3.0).exp();
    write_json(&json!({
        "reference_costs": refs,
        "candidate_costs": costs,
        "aggregate_score_projection": score,
        "is_official_leaderboard_score": false
    }));
}

fn values_u32(value: &Value, name: &str) -> Vec<u32> {
    value.as_array().unwrap_or_else(|| fail(&format!("{name} must be an array")))
        .iter().map(|x| x.as_u64().unwrap_or_else(|| fail(&format!("{name} entries must be unsigned integers"))) as u32).collect()
}

fn precision_grid(path: &str) {
    let input = read_json(path);
    let idx = values_u32(&input["index_bits"], "index_bits");
    let coef = values_u32(&input["coef_bits"], "coef_bits");
    let slope = values_u32(&input["slope_bits"], "slope_bits");
    let delta = values_u32(&input["delta_bits"], "delta_bits");
    let square = values_u32(&input["square_bits"], "square_bits");
    let product = values_u32(&input["product_bits"], "product_bits");
    let result = values_u32(&input["result_bits"], "result_bits");
    let mut rows: Vec<Precision> = Vec::new();
    for i in &idx {
        for c in &coef {
            for s in &slope {
                for d in &delta {
                    for q in &square {
                        for p in &product {
                            for r in &result {
                                // Domain checks only; Python runs exact accuracy/overflow tests.
                                if *i < 3 || *i > 12 || *c == 0 || *s == 0 || *d == 0 || *q == 0 || *p == 0 || *r == 0 {
                                    continue;
                                }
                                rows.push(Precision {
                                    index_bits: *i, coef_bits: *c, slope_bits: *s,
                                    delta_bits: *d, square_bits: *q, product_bits: *p,
                                    result_bits: *r,
                                });
                            }
                        }
                    }
                }
            }
        }
    }
    rows.sort(); rows.dedup();
    let payload = serde_json::to_vec(&rows).unwrap();
    let id = format!("{:x}", Sha256::digest(&payload));
    write_json(&json!({"grid_id":id,"count":rows.len(),"warning":"Configurations are proposals only; run the exact fixed-point model and official verifier before promotion.","candidates":rows}));
}

fn dominates(a: &ResourceCandidate, b: &ResourceCandidate) -> bool {
    let no_worse = a.qubits <= b.qubits && a.toffoli_like <= b.toffoli_like && a.t_count <= b.t_count && a.cost <= b.cost;
    let better = a.qubits < b.qubits || a.toffoli_like < b.toffoli_like || a.t_count < b.t_count || a.cost < b.cost;
    no_worse && better
}

fn pareto_file(path: &str) {
    let input = read_json(path);
    let entries: Vec<ResourceCandidate> = serde_json::from_value(input).unwrap_or_else(|e| fail(&format!("expected candidate array: {e}")));
    let mut frontier: Vec<ResourceCandidate> = Vec::new();
    for candidate in &entries {
        if !candidate.cost.is_finite() || candidate.cost <= 0.0 { continue; }
        if entries.iter().any(|other| other.id != candidate.id && dominates(other,candidate)) { continue; }
        if !frontier.iter().any(|x| x.id == candidate.id) { frontier.push(candidate.clone()); }
    }
    frontier.sort_by(|a,b| a.cost.partial_cmp(&b.cost).unwrap());
    write_json(&json!({"input_count":entries.len(),"pareto_count":frontier.len(),"minimize":["qubits","toffoli_like","t_count","cost"],"frontier":frontier}));
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 3 { fail("usage: apedp-q-core <score|grid|pareto> <input.json>"); }
    match args[1].as_str() {
        "score" => score_file(&args[2]),
        "grid" => precision_grid(&args[2]),
        "pareto" => pareto_file(&args[2]),
        _ => fail("unknown command; use score, grid or pareto"),
    }
}
