# Validation scope

The tests are pure-arithmetic regression checks. They verify formula evaluation, fixed-lambda consistency, external implied-lambda discrepancies, and geometric-mean recomputation. They do not execute or verify quantum circuits.
