#!/usr/bin/env python3
"""Recompute V4 chemistry sensitivity scenarios using one fixed lambda_eff.

This script is arithmetic-only. It does not authenticate source claims or verify circuits.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

REFERENCE_CHEM = 3_355_599_588.3155365
LAMBDA_EFF = 49.25
Q_TOTAL = 661
REFERENCE_INVSQRT = 2_076_774.233715282
REFERENCE_DQI = 24_439_463_583_672.93
INV_CLAIM = 158_763.70
DQI_CLAIM = 1_697_639_528_784.0

SCENARIOS = {
    "direct_asserted_T": {"toffoli_total": 65_244, "claim_cost": 2_123_803_639.40},
    "literal_formula_T": {"toffoli_total": 69_607, "claim_cost": None},
    "phase_term_included_T": {"toffoli_total": 72_039, "claim_cost": 2_345_190_095.0},
}

def portfolio_score(chem_cost: float) -> dict[str, float]:
    gains = {
        "invsqrt": REFERENCE_INVSQRT / INV_CLAIM,
        "dqi": REFERENCE_DQI / DQI_CLAIM,
        "dfthcsos": REFERENCE_CHEM / chem_cost,
    }
    product = gains["invsqrt"] * gains["dqi"] * gains["dfthcsos"]
    return {"gains": gains, "product_improvement": product, "geometric_mean": product ** (1.0 / 3.0)}

def build_report() -> dict:
    rows = []
    for name, s in SCENARIOS.items():
        T = s["toffoli_total"]
        cost = LAMBDA_EFF * Q_TOTAL * T
        implied_lambda = None if s["claim_cost"] is None else s["claim_cost"] / (Q_TOTAL * T)
        rows.append({
            "scenario": name,
            "toffoli_total": T,
            "fixed_lambda_eff": LAMBDA_EFF,
            "q_total": Q_TOTAL,
            "consistent_cost": cost,
            "chemistry_gain_vs_reference": REFERENCE_CHEM / cost,
            "composite_score_using_reported_inv_dqi_costs": portfolio_score(cost),
            "externally_claimed_cost": s["claim_cost"],
            "lambda_implied_by_external_cost": implied_lambda,
            "external_cost_minus_consistent_cost": None if s["claim_cost"] is None else s["claim_cost"] - cost,
        })
    return {
        "scope": "arithmetic reconciliation only; no KMB compilation or official verifier run",
        "cost_contract": "C_chem = lambda_eff * Q_total * T_total",
        "fixed_inputs": {
            "lambda_eff": LAMBDA_EFF,
            "q_total": Q_TOTAL,
            "reference_chemistry_cost": REFERENCE_CHEM,
            "invsqrt_reference_cost": REFERENCE_INVSQRT,
            "invsqrt_claim_cost": INV_CLAIM,
            "dqi_reference_cost": REFERENCE_DQI,
            "dqi_claim_cost": DQI_CLAIM,
        },
        "toffoli_formula_recheck": {
            "25_times_1129_times_2_plus_13157": 25 * 1129 * 2 + 13157,
            "asserted_total": 65244,
            "literal_formula_minus_asserted": (25 * 1129 * 2 + 13157) - 65244,
            "phase_term_2432_added_to_literal": 25 * 1129 * 2 + 13157 + 2432,
        },
        "scenarios": rows,
        "diagnosis": (
            "The three externally supplied cost figures are not all generated from one fixed lambda_eff=49.25. "
            "Keep the claimed costs as source claims, but use the consistent_cost column for like-for-like sensitivity. "
            "The verifier's measured T_total, Q_total and lambda_eff must decide final promotion."
        ),
        "promotion_decision": "HOLD_FOR_SOURCE_COST_RECEIPT_RECONCILIATION",
    }

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, default=Path("reports/consistent_cost_basis.json"))
    args = ap.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    report = build_report()
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "literal_formula_T": report["toffoli_formula_recheck"]["25_times_1129_times_2_plus_13157"], "promotion_decision": report["promotion_decision"]}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
