import importlib.util
from pathlib import Path

SCRIPT = Path(__file__).parents[1] / "scripts" / "audit_consistent_cost_basis.py"
spec = importlib.util.spec_from_file_location("cost_audit", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(mod)

def test_toffoli_arithmetic():
    r = mod.build_report()["toffoli_formula_recheck"]
    assert r["25_times_1129_times_2_plus_13157"] == 69607
    assert r["literal_formula_minus_asserted"] == 4363
    assert r["phase_term_2432_added_to_literal"] == 72039

def test_all_scenarios_use_one_lambda():
    report = mod.build_report()
    for row in report["scenarios"]:
        assert row["consistent_cost"] == mod.LAMBDA_EFF * mod.Q_TOTAL * row["toffoli_total"]
        assert row["fixed_lambda_eff"] == 49.25

def test_external_claims_reveal_lambda_mismatch():
    rows = {r["scenario"]: r for r in mod.build_report()["scenarios"]}
    assert abs(rows["direct_asserted_T"]["lambda_implied_by_external_cost"] - 49.25) > 0.003
    assert abs(rows["phase_term_included_T"]["lambda_implied_by_external_cost"] - 49.25) < 0.001

def test_score_recomputed_from_consistent_cost():
    report = mod.build_report()
    for row in report["scenarios"]:
        C = row["consistent_cost"]
        direct = (mod.REFERENCE_INVSQRT / mod.INV_CLAIM * mod.REFERENCE_DQI / mod.DQI_CLAIM * mod.REFERENCE_CHEM / C) ** (1/3)
        assert abs(row["composite_score_using_reported_inv_dqi_costs"]["geometric_mean"] - direct) < 1e-12

def test_no_claim_of_verification():
    report = mod.build_report()
    assert "no KMB compilation" in report["scope"]
    assert report["promotion_decision"].startswith("HOLD")
