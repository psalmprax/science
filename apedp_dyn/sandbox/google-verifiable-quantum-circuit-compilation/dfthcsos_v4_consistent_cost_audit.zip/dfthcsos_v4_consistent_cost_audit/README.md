# DFTHCSOS V4 Consistent-Cost Audit

This package performs arithmetic-only reconciliation of the V4 four-bank chemistry Toffoli scenarios under a **single fixed** `lambda_eff=49.25` and `Q_total=661`.

It checks the literal expression `25 * 1129 * 2 + 13157 = 69607`, the asserted `65244`, and the optional `2432` term (`72039`). It recomputes chemistry costs and the composite geometric mean while retaining the supplied inverse-square-root and DQI claimed costs.

Run from this directory:

```bash
python scripts/audit_consistent_cost_basis.py --output reports/consistent_cost_basis.json
pytest -q tests
```

This is not a circuit compiler, KMB serializer, Kickmix simulation, or official verifier. Promotion remains blocked until full-precision source resource counts and the official receipt agree.
