# Signed 4-address banking / V4 claim audit pack

This pack takes the V4 summary as a set of claims to audit. It implements a classical 4-address table transform and recomputes portfolio arithmetic. It does **not** implement a Kickmix ANGLE circuit and does not contain the external release artifacts, frozen chemistry input, or official verifier.

## Findings from the arithmetic audit

The submitted Benchmark III line says `25 * 1,129 * 2 + 13,157 = 65,244`. The left-hand side is **69,607**. With the literal formula and `lambda_eff=49.25`, `Q_total=661`, the chemistry cost is **2,266,003,679.75**, an improvement factor of about **1.481x**. With the directly stated `T_total=65,244`, cost is **2,123,969,487.00**, not the stated `2,123,803,639.40`. The latter implies either `lambda_eff≈49.24615437` for T=65,244 or a non-integer T≈65,238.9055 for lambda=49.25.

For Benchmark II, `R=1.19126046`, `Q=1,789`, `T_mean=445,229` gives **1,697,504,180,614.53**, not 1,697,639,528,784. The claimed cost implies T_mean≈445,264.50. A verifier receipt with full-precision values is needed to decide which input is authoritative.

For Benchmark I, retaining full floating-point precision from the supplied calibration formula gives a score cost around **158,764.45**. The reported 158,763.70 is consistent with rounding the rotation-synthesis cost before aggregating; this is a small rounding difference and not comparable to the Benchmark III discrepancy.

The portfolio score is the geometric mean of the three reference/candidate cost ratios. With the literal Benchmark III formula above, the score recomputes to about **6.53**; using the directly asserted T_total=65,244 instead gives about **6.68**. Thus the headline depends on resolving the chemistry accounting discrepancy.

## 4-address transform

For `N_angles=75`, `J=3`, `K=ceil(75/3)=25`. Four-address groups reduce `3976` rows to `994`. For each row, retain `base=D[4h]` and encode `delta_j = D[4h+j] XOR base` for j=1,2,3.

The compact delta representation is only accepted when all 10-bit angle words meet `bit9 == bit8`; then each 10-bit word can be losslessly represented with 9 bits and reconstructed by duplicating its high bit. Tests exercise all 512 codes satisfying this condition and an exhaustive 25 × 3 × 3976 synthetic table round trip.

The proposed angle-circuit width adds to exactly `12 + 30 + 81 + 5 = 128`, leaving **zero headroom**. One extra qubit breaks the hard cap. The `Q_total=661` plan is marked as an assumption (`634 + 12J - 3J`), not treated as proven until reconciled with the exact verifier resource model and actual serialized circuits.

## Run

```bash
python scripts/audit_v4_claims.py --output reports/v4_claim_audit.json
python scripts/plan_signed_4bank.py --output-dir reports/signed_4bank
pytest -q tests
```

To transform real tables, export a no-pickle NPZ array `batch_angle_words` with shape `(25,3976,3)`, one 10-bit code per angle, derived from the exact frozen reference source. Then run:

```bash
python scripts/plan_signed_4bank.py --table-npz /path/to/angle_words.npz --output-dir artifacts/arm3
```

Do not create an NPZ by guessing the private data layout. Validate its provenance against the official incumbent receipt.

## Promotion gates

1. Reconcile the conflicting frozen-input hashes seen in the prior APEDP-Q work and V4 release lineage.
2. Check `bit9 == bit8` on every actual codeword before enabling 9-bit delta encoding. The signed-code interpretation and rounding endpoint behavior must match the official generator.
3. Implement the delta lookup and measured cleanup in Kickmix; validate `read_phase_flipped_across_shots()` and all returned words on the exact trajectory.
4. Serialize all 25 `.kmb` files, measure actual peak qubits and forward/reverse Toffolis, and reconcile every non-angle cost component with the unchanged verifier source.
5. Run the unchanged official chemistry verifier with the official data and preserve the exact receipt/hashes. No projection is a pass.

The verifier's actual standard cost counts ANGLE circuits once forward and once in reverse, and checks the recovered words, cleanup, and phase. See the source paper and Google announcement:
- https://hub.valency.io/works/W_c92w3zey
- https://www.googblogs.com/announcing-the-verifiable-quantum-circuit-compilation-competition-on-kaggle/
