import math
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from plan_signed_4bank import (ANGLE_BATCH_COUNT, ADDRESS_COUNT, J, B, EXPECTED_SHAPE,
    compress10_to9, decompress9_to10, four_bank, reconstruct_four_bank, plan)
from audit_v4_claims import audit


def synthetic_valid_words(seed=20261025):
    rng = np.random.default_rng(seed)
    # 10-bit two's complement encodings of signed values [-256,255].
    signed = rng.integers(-256, 256, size=EXPECTED_SHAPE, dtype=np.int16)
    return (signed & 0x3FF).astype(np.uint16)


def test_signed_word_codec_roundtrip_exhaustive():
    codes = np.arange(1024, dtype=np.uint16)
    valid = codes[((codes >> 9) & 1) == ((codes >> 8) & 1)]
    assert len(valid) == 512
    assert np.array_equal(decompress9_to10(compress10_to9(valid)), valid)


def test_four_bank_classical_roundtrip_full_shape():
    words = synthetic_valid_words()
    base, delta = four_bank(words)
    assert base.shape == (25, 994, 3)
    assert delta.shape == (25, 994, 3, 3)
    assert np.array_equal(reconstruct_four_bank(base, delta), words)


def test_rejects_nonredundant_top_bits():
    words = synthetic_valid_words()
    words[0, 0, 0] = 0b0100000000
    try:
        four_bank(words)
    except ValueError as exc:
        assert 'bit9==bit8' in str(exc)
    else:
        raise AssertionError('invalid signed-angle word was accepted')


def test_layout_cap_is_exactly_saturated():
    p = plan()
    w = p['angle_circuit_width_components']
    assert w['peak_qubits_estimate'] == 12 + 30 + 81 + 5 == 128
    assert w['headroom'] == 0
    assert p['angle_circuits_K'] == 25
    assert p['bank_rows_per_batch'] == 3976 // 4 == 994


def test_audit_catches_v4_chemistry_formula_mismatch():
    r = audit()
    chem = r['benchmark_iii']
    assert chem['literal_t_total_from_formula'] == 69607
    assert chem['claimed_t_total'] == 65244
    assert chem['t_formula_minus_claim'] == 4363
    assert math.isclose(chem['cost_from_literal_formula'], 2_266_003_679.75)
    assert r['portfolio']['geometric_mean_using_literal_chemistry_formula'] < 6.54
    assert r['verification_status']['official_verifier_run_here'] is False
