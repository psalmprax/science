#!/usr/bin/env python3
"""Recompute arithmetic in the supplied V4 portfolio summary.

This audits stated formulas and reported numbers; it does not verify any circuit,
Kaggle artifact, or official receipt.
"""
from __future__ import annotations
import json, math
from pathlib import Path

REF_INV = 2_076_774.233715282
REF_DQI = 24_439_463_583_672.93
REF_CHEM = 3_355_599_588.3155365


def audit() -> dict:
    # Benchmark I: preserve the supplied equation and avoid rounding until end.
    margin = 73_326_605
    rotations = 44
    epsilon = math.pi * margin / (2**64 * rotations)
    t_per_rotation = 0.56 * math.log2(1.0 / epsilon) + 5.3
    t_total = rotations * t_per_rotation
    t_equiv = t_total / 4.0
    inv_static_toffoli = 1_449
    inv_q = 90
    inv_equiv = inv_static_toffoli + t_equiv
    inv_cost = inv_q * inv_equiv

    # Benchmark II: recompute from the literal values in the pasted claim.
    dqi_r = 1.19126046
    dqi_q = 1_789
    dqi_t_mean = 445_229
    dqi_cost = dqi_r * dqi_q**2 * dqi_t_mean
    claimed_dqi_cost = 1_697_639_528_784.0
    dqi_t_implied_by_claimed_cost = claimed_dqi_cost / (dqi_r * dqi_q**2)

    # Benchmark III: evaluate the stated algebra exactly as written.
    lam = 49.25
    chem_q = 661
    angle_circuits = 25
    angle_toffolis_per_pass = 1_129
    non_angle_toffolis = 13_157
    chem_t_from_formula = angle_circuits * angle_toffolis_per_pass * 2 + non_angle_toffolis
    chem_t_direct_claim = 65_244
    chem_cost_from_formula = lam * chem_q * chem_t_from_formula
    chem_cost_from_direct_t = lam * chem_q * chem_t_direct_claim
    claimed_chem_cost = 2_123_803_639.40
    implied_lambda_given_direct_t = claimed_chem_cost / (chem_q * chem_t_direct_claim)
    implied_t_given_lambda = claimed_chem_cost / (lam * chem_q)

    f_inv = REF_INV / inv_cost
    f_dqi = REF_DQI / dqi_cost
    f_chem_formula = REF_CHEM / chem_cost_from_formula
    f_chem_direct = REF_CHEM / chem_cost_from_direct_t
    product_formula = f_inv * f_dqi * f_chem_formula
    gm_formula = product_formula ** (1 / 3)
    product_direct = f_inv * f_dqi * f_chem_direct
    gm_direct = product_direct ** (1 / 3)

    # Isolate the user's rounded arithmetic to make discrepancies auditable.
    rounded_inv_cost = 90 * (1_449 + 315.04)
    b2_cost_count = 19 * 1_987 * 2 + 2_432 + 13_157
    b4_count_plus_2432 = chem_t_from_formula + 2_432

    return {
      "scope": "arithmetic_only_not_circuit_verification",
      "references": {"invsqrt": REF_INV, "dqi": REF_DQI, "dfthcsos": REF_CHEM},
      "benchmark_i": {
        "input": {"q": inv_q, "static_toffoli": inv_static_toffoli, "rotations": rotations,
                  "margin_integer_units": margin},
        "epsilon": epsilon, "t_gates_per_rotation": t_per_rotation,
        "t_gates_all_rotations": t_total, "rotation_toffoli_equivalent": t_equiv,
        "toffoli_equivalent_total": inv_equiv, "cost_unrounded": inv_cost,
        "cost_using_claim_rounded_1764_04": rounded_inv_cost,
        "claim_cost": 158_763.70, "recomputed_gain_factor": f_inv,
        "difference_unrounded_vs_claim": inv_cost - 158_763.70,
        "note": "The reported cost uses a rounded rotation cost; retaining precision changes the cost slightly."
      },
      "benchmark_ii": {
        "input": {"r": dqi_r, "q": dqi_q, "mean_toffolis": dqi_t_mean},
        "recomputed_cost": dqi_cost, "claimed_cost": claimed_dqi_cost,
        "difference_recomputed_minus_claim": dqi_cost - claimed_dqi_cost,
        "mean_toffolis_implied_by_claimed_cost": dqi_t_implied_by_claimed_cost,
        "recomputed_gain_factor": f_dqi,
        "note": "The stated Q and T values do not exactly reproduce the reported cost; the reported cost implies a different mean Toffoli count."
      },
      "benchmark_iii": {
        "input": {"lambda_eff": lam, "q_total": chem_q, "angle_circuits": angle_circuits,
                  "toffolis_per_angle_circuit_per_pass": angle_toffolis_per_pass,
                  "passes": 2, "non_angle_toffolis": non_angle_toffolis},
        "literal_t_total_from_formula": chem_t_from_formula,
        "claimed_t_total": chem_t_direct_claim,
        "t_formula_minus_claim": chem_t_from_formula - chem_t_direct_claim,
        "cost_from_literal_formula": chem_cost_from_formula,
        "gain_from_literal_formula": f_chem_formula,
        "cost_from_direct_claimed_t": chem_cost_from_direct_t,
        "gain_from_direct_claimed_t": f_chem_direct,
        "claimed_cost": claimed_chem_cost,
        "lambda_implied_by_claimed_cost_and_t": implied_lambda_given_direct_t,
        "t_implied_by_claimed_cost_and_lambda": implied_t_given_lambda,
        "b4_toffolis_if_the_separate_2432_term_also_applies": b4_count_plus_2432,
        "arm2_toffoli_expression_as_pasted": b2_cost_count,
        "note": "25 * 1,129 * 2 + 13,157 equals 69,607, not 65,244. The listed cost also does not exactly equal 49.25 * 661 * 65,244. Whether the separate 2,432 term applies to B=4 must be settled from verifier/source accounting."
      },
      "portfolio": {
        "factors_using_literal_chemistry_formula": {"invsqrt": f_inv, "dqi": f_dqi, "dfthcsos": f_chem_formula},
        "product_improvement_using_literal_chemistry_formula": product_formula,
        "geometric_mean_using_literal_chemistry_formula": gm_formula,
        "factors_using_direct_claimed_chemistry_t_65244": {"invsqrt": f_inv, "dqi": f_dqi, "dfthcsos": f_chem_direct},
        "product_improvement_using_direct_claimed_chemistry_t": product_direct,
        "geometric_mean_using_direct_claimed_chemistry_t": gm_direct,
        "claimed_product_improvement": 297.5,
        "claimed_geometric_mean": 6.6759,
        "interpretation": "The headline near 6.68 is consistent with using chemistry T=65,244 as a direct input, but the supplied formula for that T is inconsistent. Using the formula's actual result gives a lower geometric mean near 6.53 before any other source/receipt discrepancies are resolved."
      },
      "verification_status": {
        "external_v4_claims_independently_verified_here": False,
        "official_verifier_run_here": False,
        "kmb_artifacts_available_here": False,
        "promotion_decision": "HOLD_FOR_ARITHMETIC_AND_RECEIPT_RECONCILIATION"
      }
    }


def main() -> int:
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, default=Path('reports/v4_claim_audit.json'))
    a = p.parse_args()
    out = audit()
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({"output": str(a.output),
                      "literal_chemistry_t_total": out['benchmark_iii']['literal_t_total_from_formula'],
                      "claimed_chemistry_t_total": out['benchmark_iii']['claimed_t_total'],
                      "geometric_mean_literal_formula": out['portfolio']['geometric_mean_using_literal_chemistry_formula'],
                      "promotion_decision": out['verification_status']['promotion_decision']}, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
