#!/usr/bin/env python3
"""Plan and classically validate signed 4-address banking for J=3 ANGLE tables.

The command emits a resource/layout plan, or transforms an NPZ table when the
caller supplies --table-npz. It does not compile Kickmix or validate phases.
"""
from __future__ import annotations
import argparse, hashlib, importlib, json
from pathlib import Path
import numpy as np

N_ANGLES = 75
ADDRESS_COUNT = 3976
J = 3
B = 4
WORD_BITS = 10
REDUCED_BITS = 9
ANGLE_BATCH_COUNT = (N_ANGLES + J - 1) // J
QUBIT_CAP = 128
EXPECTED_SHAPE = (ANGLE_BATCH_COUNT, ADDRESS_COUNT, J)


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def validate_words(words: np.ndarray) -> np.ndarray:
    arr = np.asarray(words)
    if arr.shape != EXPECTED_SHAPE:
        raise ValueError(f"expected angle words shape {EXPECTED_SHAPE}, got {arr.shape}")
    if arr.dtype.kind not in 'iu':
        raise ValueError('angle words must be integer dtype')
    if np.any(arr < 0) or np.any(arr >= (1 << WORD_BITS)):
        raise ValueError('angle words must lie in [0,1023]')
    # The compact 9-bit delta encoding is valid only if every word has equal top bits.
    b9 = (arr >> 9) & 1
    b8 = (arr >> 8) & 1
    if not np.array_equal(b9, b8):
        bad = np.argwhere(b9 != b8)[0].tolist()
        raise ValueError(f"signed-angle redundancy bit9==bit8 failed at index {bad}")
    return arr.astype(np.uint16, copy=False)


def compress10_to9(words: np.ndarray) -> np.ndarray:
    arr = np.asarray(words)
    if np.any(arr < 0) or np.any(arr >= 1024):
        raise ValueError('word outside 10-bit range')
    if np.any(((arr >> 9) & 1) != ((arr >> 8) & 1)):
        raise ValueError('cannot compress word whose bit9 != bit8')
    return ((((arr >> 9) & 1) << 8) | (arr & 0xFF)).astype(np.uint16)


def decompress9_to10(compact: np.ndarray) -> np.ndarray:
    c = np.asarray(compact)
    if c.dtype.kind not in 'iu' or np.any(c < 0) or np.any(c >= 512):
        raise ValueError('compact word must be an integer in [0,511]')
    top = (c >> 8) & 1
    return ((top << 9) | (top << 8) | (c & 0xFF)).astype(np.uint16)


def four_bank(words: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return base 10-bit words and three 9-bit XOR deltas per 4-address bank."""
    arr = validate_words(words)
    blocks = arr.reshape(ANGLE_BATCH_COUNT, ADDRESS_COUNT // B, B, J)
    base = blocks[:, :, 0, :].copy()
    deltas10 = np.bitwise_xor(blocks[:, :, 1:, :], base[:, :, None, :])
    # XOR preserves the bit9==bit8 invariant, so delta values also fit 9 bits.
    deltas9 = compress10_to9(deltas10)
    return base, deltas9


def reconstruct_four_bank(base: np.ndarray, deltas9: np.ndarray) -> np.ndarray:
    b = np.asarray(base)
    d = np.asarray(deltas9)
    expected_base = (ANGLE_BATCH_COUNT, ADDRESS_COUNT // B, J)
    expected_d = (ANGLE_BATCH_COUNT, ADDRESS_COUNT // B, B - 1, J)
    if b.shape != expected_base:
        raise ValueError(f"base shape must be {expected_base}, got {b.shape}")
    if d.shape != expected_d:
        raise ValueError(f"delta shape must be {expected_d}, got {d.shape}")
    delta10 = decompress9_to10(d)
    blocks = np.empty((ANGLE_BATCH_COUNT, ADDRESS_COUNT // B, B, J), dtype=np.uint16)
    blocks[:, :, 0, :] = b
    for offset in range(1, B):
        blocks[:, :, offset, :] = np.bitwise_xor(b, delta10[:, :, offset - 1, :])
    out = blocks.reshape(EXPECTED_SHAPE)
    return validate_words(out)


def plan() -> dict:
    rows = ADDRESS_COUNT // B
    width = 12 + J * WORD_BITS + (B - 1) * J * REDUCED_BITS + 5
    # The claimed persistent-qubit formula reduces each of J registers by 3;
    # this remains a hypothesis until checked against the exact verifier model.
    claimed_q_total = 634 + 12 * J - 3 * J
    return {
        'status': 'PLANNED_NOT_COMPILED',
        'design': 'signed_4_address_banking',
        'source_assumption': '10-bit two-complement-like angle words are in [-256,255] and therefore satisfy bit9 == bit8; the actual frozen words must be checked.',
        'N_angles': N_ANGLES, 'J': J, 'angle_circuits_K': ANGLE_BATCH_COUNT,
        'address_count': ADDRESS_COUNT, 'block_size_B': B, 'bank_rows_per_batch': rows,
        'base_word_bits_per_row': J * WORD_BITS,
        'delta_bank_count': B - 1,
        'compressed_delta_bits_per_bank_row': (B - 1) * J * REDUCED_BITS,
        'angle_circuit_width_components': {
            'selection_qubits': 12,
            'full_output_words': J * WORD_BITS,
            'delta_bank': (B - 1) * J * REDUCED_BITS,
            'scratch': 5,
            'peak_qubits_estimate': width,
            'cap': QUBIT_CAP,
            'headroom': QUBIT_CAP - width,
        },
        'claimed_Q_total': claimed_q_total,
        'Q_total_formula_assumption': '634 + 12J - 3J; must be matched to official verifier/source resource accounting before promotion.',
        'classical_transform': {'lookup_equivalence': 'not_run_without_real_npz', 'phase_semantics': 'not_applicable_to_classical_table', 'compiled_kmb': False},
        'cost_accounting': {'angles_forward_reverse_factor': 2,
                            'must_use_per_circuit_Toffolis_from_Kickmix_simulator': True,
                            'non_angle_cost_components_need_source_reconciliation': True},
        'promotion_gate': ['frozen input hash matches receipt', 'all 25 real ANGLE circuits <=128 qubits',
                           'all recovered words match reference', 'phase/read_phase_flipped_across_shots checks pass',
                           'official verify.py PASS', 'official cost strictly below pinned incumbent'],
    }


def import_callable(path: str):
    module, sep, name = path.partition(':')
    if not sep:
        raise ValueError('adapter must be module:function')
    return getattr(importlib.import_module(module), name)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--table-npz', type=Path, help="NPZ with array 'batch_angle_words' shape (25,3976,3)")
    p.add_argument('--adapter', help='local module:function returning batch_angle_words')
    p.add_argument('--output-dir', type=Path, default=Path('artifacts/quantum_compilation/dfthcsos/arm3/signed_4bank_j3'))
    p.add_argument('--output-json', type=Path)
    a = p.parse_args()
    out = plan()
    if a.table_npz and a.adapter:
        p.error('choose either --table-npz or --adapter')
    if a.table_npz or a.adapter:
        if not a.table_npz:
            p.error('--table-npz is required for this portable pack; run your local adapter to export an NPZ first')
        with np.load(a.table_npz, allow_pickle=False) as z:
            if 'batch_angle_words' not in z:
                p.error("input NPZ must have 'batch_angle_words'")
            words = validate_words(z['batch_angle_words'])
        base, delta = four_bank(words)
        recovered = reconstruct_four_bank(base, delta)
        ok = bool(np.array_equal(words, recovered))
        if not ok:
            raise SystemExit('4-bank reconstruction failed')
        a.output_dir.mkdir(parents=True, exist_ok=True)
        payload = a.output_dir / 'signed_4bank_j3_tables.npz'
        np.savez_compressed(payload, base_words=base, delta_words_9bit=delta)
        out['classical_transform'] = {
            'status': 'CLASSICAL_EQUIVALENCE_PASS',
            'lookup_equivalence_all_addresses': ok,
            'table_sha256': sha256_bytes(words.tobytes()),
            'packed_npz_path': str(payload),
            'base_shape': list(base.shape), 'delta_shape': list(delta.shape),
            'compiled_kmb': False, 'official_verifier_run': False,
        }
    outpath = a.output_json or (a.output_dir / 'signed_4bank_plan.json')
    outpath.parent.mkdir(parents=True, exist_ok=True)
    outpath.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({'output': str(outpath), 'status': out['status'],
                      'peak_qubits_estimate': out['angle_circuit_width_components']['peak_qubits_estimate'],
                      'angle_circuits_K': out['angle_circuits_K'],
                      'table_transform_run': 'CLASSICAL_EQUIVALENCE_PASS' in out['classical_transform'].get('status','')}, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
