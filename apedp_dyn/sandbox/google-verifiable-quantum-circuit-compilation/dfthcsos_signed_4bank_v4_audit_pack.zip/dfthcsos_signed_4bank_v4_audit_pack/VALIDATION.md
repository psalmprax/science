# Validation scope

- Arithmetic audit: deterministic local Python calculations; no external V4 receipt was available to compare.
- Classical table codec: test-only synthetic 10-bit two's-complement encodings, exhaustive over all representable codes with equal high bits.
- Four-bank round trip: synthetic array of shape `(25, 3976, 3)`, reconstructed with exact equality.
- Not validated: real public word dataset, reference provenance, Kickmix semantics, HMR/select phase correction, `.kmb` serialization, official verifier, official V4 score.
