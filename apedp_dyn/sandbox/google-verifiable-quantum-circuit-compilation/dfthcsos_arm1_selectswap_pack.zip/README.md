# DFTHCSOS Arm 1 — SelectSwap-only experiment gate

This is an **experiment protocol and receipt auditor**, not a SelectSwap compiler. The exact source adapter and official chemistry verifier must come from the user's APEDP-Q / competition checkout. Do not treat this pack as a compiled circuit or an official verification result.

## Arm isolation

Arm 1 must introduce SelectSwap only. Keep Reed–Muller angle buffering, buffered-delta encoding, new HMR phase-fixup logic, lambda refitting, integral changes, and unrelated circuit rewrites disabled. Apply the candidate transform to the exact incumbent ANGLE subcircuits required by the actual builder and leave the chemistry input data (`submission.npz`) unchanged unless the official circuit construction requires otherwise and records that change explicitly.

## Pre-flight

1. Freeze the current official chemistry baseline receipt and SHA-256 hashes of all source members, especially `submission.npz` and `angle_k_0.kmb` through `angle_k_7.kmb`.
2. Re-run or authenticate the baseline against the same official verifier version and configuration used for the candidate.
3. Measure the peak qubits of each exact baseline `angle_k_*.kmb` circuit. Choose SelectSwap workspace budgets only from the measured headroom: each angle circuit must stay at or below 128 qubits. Do not reuse the 123-qubit figure from a different artifact unless its hash matches this baseline.
4. For each workspace/block configuration, compile a candidate without any Arm 2 changes. Record the builder revision, configuration, source hashes, candidate hashes, and all compile diagnostics.

## Required checks per candidate

- All eight ANGLE subcircuits are present, and each complies with the strict 128-qubit per-circuit cap.
- QROM address-to-word behavior matches the original table for the full legal address range, and all required input restoration, scratch cleanup, and phase semantics are checked for the actual transformation.
- Chemistry invariants are retained: the official two-body error bound (≤ 1e-3 Ha per the project protocol), lambda/effective-normalization conditions, and all other official verifier constraints.
- Run the unchanged official DFTHCSOS verifier against the actual candidate artifact. A local unit test, resource estimate, or plan-only result is not sufficient.
- Compare the verifier's full-precision score with the verified baseline score. Promote only if the verifier passes and the cost is strictly lower.

## Score reconciliation

The reported chemistry cost contract is `C = lambda_eff * Q_total * T_total`; the verifier's reported score remains authoritative. Save the full-precision `lambda_eff`, total qubits, total Toffoli count, score, verifier version, artifact/member hashes, and complete verifier output. The user-facing reference values `lambda_eff = 49.3612`, `Q=730`, `T=93,124` are rounded; multiplying the rounded lambda gives 3,355,600,043.824, about 455.504 above the pinned reference score 3,355,599,588.32. This tiny difference is consistent with the lambda being rounded and is not evidence of a scoring bug by itself.

## Receipt auditor

After the baseline and candidate full verifier JSON receipts are saved, run:

```bash
python scripts/audit_dfthcsos_arm1_receipts.py \
  --baseline artifacts/quantum_compilation/dfthcsos/arm1/baseline_receipt.json \
  --candidate artifacts/quantum_compilation/dfthcsos/arm1/candidate_receipt.json \
  --output artifacts/quantum_compilation/dfthcsos/arm1/audit.json
```

The auditor checks receipt fields, the cost identity, the optional explicit per-ANGLE cap flag if present, and whether a passing candidate strictly improves on the baseline. It cannot independently verify circuit semantics; only the official verifier can do that.
