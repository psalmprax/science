# Validation

Run:

```bash
python3.13 -m pytest -q tests/test_receipt_runner_hardening.py
python3.13 -m py_compile scripts/run_official_receipts.py
```

The included tests validate fail-closed placeholder rejection, exact hash pinning, root selection, source-file snapshots, and executable-token preflight. They do not run or emulate any official quantum-circuit verifier.
