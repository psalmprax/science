# Validation boundaries

Tests cover the J=4/19-batch layout, the 71+48=119 raw-width arithmetic, the 682-qubit analytical total, 12-bit input constraints, adjacent-address XOR pairing, and exact reconstruction of every address for a deterministic synthetic table.

They do not use competition angle values, compile Kickmix circuits, validate HMR measurement correction, prove quantum phase semantics, measure actual circuit width/gate count, or invoke the official DFTHCSOS verifier. The analytical score range is a hypothesis until the exact local adapter and compiler run.
