# DFTHCSOS `rm_block2_j4`: table build and profiling harness

This is the next step after the Arm 2 planning pack. It implements and tests the **classical table transform** for paired-address buffering, emits a conservative analytical resource projection, and provides a defined adapter contract for the user's exact ANGLE table generator.

It does **not** yet emit `.kmb`/`.kmx` circuits, implement Kickmix HMR phase correction, or run the official chemistry verifier. The current session filesystem does not contain the exact `angle_k_reference_circuit.py`/ANGLE generator, `submission.npz`, official verifier bundle, or `kickmix` runtime, so claiming those steps would be misleading.

## Candidate fixed for this arm

- Arm: `arm2_reed_muller_angle_buffering_only`; SelectSwap remains disabled.
- Batch size: `J=4`; 75 logical angles means `ceil(75/4)=19` ANGLE circuits.
- Input domain: 3,976 addresses, paired as `(2h, 2h+1)` for 1,988 high-address rows.
- Each lookup returns four 12-bit words (48 bits). For every pair:
  - `base[h] = table[2*h]`
  - `delta[h] = table[2*h] XOR table[2*h+1]`
  - low-bit 0 returns `base`; low-bit 1 returns `base XOR delta`.
- Data-level packed high-address row is `[base (4 words), delta (4 words)]`, a 96-bit payload.
- Width arithmetic: `12 selector + 4*12 output words + 11 baseline ancillas = 71`; plus a raw 48-bit delta buffer gives 119 qubits before any additional phase-fixup workspace. That leaves at most 9 extra qubits for such workspace, unless the exact builder safely reuses existing ancillas.
- Analytical full score model gives `Q_total = 634 + 12*J = 682`; this is still a projection pending actual official verifier measurement.

## Run the design projection now

```bash
python scripts/dfthcsos_rm_block2_j4.py \
  --output-dir artifacts/quantum_compilation/dfthcsos/arm2/rm_block2_j4
```

This writes `design_projection.json` only and reports the assumed gate/score range as **projection**, not measured result.

## Connect the exact local ANGLE reference table

Provide a local adapter `my_dfthcsos_adapter:build_batch_xor_words` with this interface:

```python
def build_batch_xor_words(submission_npz_path: pathlib.Path) -> numpy.ndarray:
    """Return exact official lookup words, shape (19, 3976, 4), dtype integer.

    batch_xor_words[k, address, word] must equal the exact word returned by
    the existing reference ANGLE semantics for batch k. For k>0 these are the
    official inter-batch XOR differences, not raw angle values. Respect the
    reference's padding rule for the final batch.
    """
```

The adapter must call the actual reference function/official table implementation rather than reconstructing values from guessed formulas. Then run:

```bash
python scripts/dfthcsos_rm_block2_j4.py \
  --submission-npz /path/to/official/sample_submission/dfthcsos/submission.npz \
  --adapter my_dfthcsos_adapter:build_batch_xor_words \
  --output-dir artifacts/quantum_compilation/dfthcsos/arm2/rm_block2_j4
```

The default SHA-256 check pins `submission.npz` to the current baseline value reported for this arm (`276d464f...c4002695`). For a changed input, override `--expected-input-sha256` only after explicitly freezing a new baseline.

Alternatively, save the adapter's return value under NPZ key `batch_xor_words` and pass `--tables-npz path/to/tables.npz`.

On success the tool emits:
- `rm_block2_j4_pair_tables.npz`: array `pair_tables`, shape `(19, 1988, 8)`, with 4 base and 4 delta words per row.
- `table_profile.json`: all-address classical reconstruction check, hashes, zero-delta/duplicate-row metrics and per-batch stats.

## What must happen next in the real workspace

1. Implement the Kickmix high-address lookup to output `[base, delta]` in one walk per batch.
2. Implement the low-address-bit controlled XOR into the four output word registers.
3. Implement and validate HMR buffer cleanup and the exact SelectSwap phase-fixup QROM. Table equality alone cannot validate relative phase.
4. Compile the 19 `.kmb` files; measure actual `num_qubits` and Toffoli-like counts, and ensure every ANGLE circuit is at most 128 qubits.
5. Verify exact input preservation and source-member hashes, disable Arm 1 and every other transform, then run the unchanged official DFTHCSOS verifier.
6. Promote only if official PASS, phase/lookup semantics pass, input and other sources remain frozen, all width caps pass, and the exact `lambda_eff * Q_total * T_total` is strictly below `3,355,599,588.3155365`.

## Interpretation of the current projection

The script uses `1988-1 = 1987` Toffolis as a structural high-address-QROM estimate per batch, and 64–95 Toffolis per phase fix-up based on the earlier project design notes. These are **not compiled counts**. The projection assumes HMR cleanup avoids a Toffoli uncompute pass, `lambda_eff` stays fixed, and all non-ANGLE costs stay fixed. It must be replaced by actual compiled and official verifier receipts.
